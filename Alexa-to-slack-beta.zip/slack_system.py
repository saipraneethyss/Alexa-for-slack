
import json as js
import requests
from slackclient import SlackClient as slack





# client_key = "3e92dfca62f0e21d2d19613d3b45f7a8"
# client_id = "266423738560.266425477648"
# client_token = "D0YOuhtpPaq2r36msc4TvZse"
# import os
# from flask import Flask, request
# from slackclient import SlackClient

# client_id = os.environ["SLACK_CLIENT_ID"]
# client_key = os.environ["SLACK_CLIENT_SECRET"]
# oauth_scope = os.environ["SLACK_BOT_SCOPE"]
# @app.route("/begin_auth", methods=["GET"])
# def pre_install():
#   return '''
#       <a href="https://slack.com/oauth/authorize?scope={0}&client_id={1}">
#           Add to Slack
#       </a>
#   '''.format(oauth_scope, client_id)

# app = Flask(__name__)
# @app.route("/finish_auth", methods=["GET", "POST"])
# def post_install():

#   # Retrieve the auth code from the request params
#   auth_code = request.args['code']

#   # An empty string is a valid token for this request
#   sc = SlackClient("")

#   # Request the auth tokens from Slack
#   auth_response = sc.api_call(
#     "oauth.access",
#     client_id=client_id,
#     client_secret=client_secret,
#     code=auth_code
#   )



#posts data on slack by taking data from Alexa. This function is called when PostToSlack intent is invoked
def post_on_slack_from_alexa(data):
	client_token = "xoxp-266423738560-266561351921-268049892342-bba7f7059297b5171a7a855f21de442c"

	sc = slack(client_token)
	sc.api_call("chat.postMessage",channel = "#kronusposts", text = data)



#gets last four messages from Slack when a voice command is sent from Alexa and getFromSlack intent is invoked
def get_messages(channel_id,count_val):
	client_token = "xoxp-266423738560-266561351921-268049892342-bba7f7059297b5171a7a855f21de442c"
	sc = slack(client_token)
	messages = sc.api_call("channels.history",channel= channel_id,count=count_val)#"C7V6G1UE9")
	new_messages = [message.get('text') for message in messages.get('messages')]
	return str(new_messages)